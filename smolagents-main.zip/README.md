---
title: Computer Agent
emoji: 🖥️🧠
colorFrom: red
colorTo: yellow
sdk: gradio
header: mini
sdk_version: 5.23.1
app_file: app.py
pinned: true
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference